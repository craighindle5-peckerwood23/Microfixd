import { randomUUID } from 'node:crypto';
import type { AutonomyRuntime } from './runtime.ts';
import type { OrganKernel } from './organ-kernel.ts';
import { listOrgans, getOrgan, organSummary } from './organ-registry.ts';

/**
 * ChatOrgan: the single free-text surface for the entire system.
 *
 * This adds NO new authority. Every branch below calls the exact same
 * runtime/OrganKernel methods the REST routes in routes.ts already call
 * -- so a chat message asking "what's the system status" and a GET to
 * /api/autonomy/introspection hit the same code and the same Paragon
 * governance. Nothing here bypasses approval: any branch that mutates
 * state (submitGoal, setSafeMode, decideApproval) still goes through
 * organs.invoke() first and still returns 'awaiting_approval' when
 * Paragon requires a human decision, exactly like the HTTP handlers do.
 *
 * This exists so a chat box under the holographic head can reach every
 * part of the infrastructure through one endpoint, instead of the
 * frontend needing to know all ~35 routes individually.
 */

export type ChatContext = {
  tenantId: string;
  requestedBy: string;
};

export type ChatResult = {
  reply: string;
  organId?: string;
  route?: string;
  data?: unknown;
  governance?: unknown;
  status: 'ok' | 'awaiting_approval' | 'denied' | 'not_understood';
};

type Intent = {
  name: string;
  patterns: RegExp[];
  describe: string;
  handle: (utterance: string, ctx: ChatContext) => Promise<ChatResult>;
};

export class ChatOrgan {
  private intents: Intent[];

  constructor(private runtime: AutonomyRuntime, private organs: OrganKernel) {
    this.intents = this.buildIntents();
  }

  async route(utterance: string, ctx: ChatContext): Promise<ChatResult> {
    const text = utterance.trim();
    if (!text) return { reply: "I didn't catch that -- could you repeat it?", status: 'not_understood' };

    for (const intent of this.intents) {
      if (intent.patterns.some((pattern) => pattern.test(text))) {
        try {
          const result = await intent.handle(text, ctx);
          await this.logUsage(intent.name, text, ctx, result);
          return result;
        } catch (error) {
          const result: ChatResult = { reply: `That request hit an error: ${(error as Error).message}`, status: 'denied' };
          await this.logUsage(intent.name, text, ctx, result);
          return result;
        }
      }
    }

    const result: ChatResult = {
      reply:
        "I didn't recognize that as one of my governed capabilities. Try: system status, list organs, agent posture, " +
        'compute status, infrastructure status, safe mode status, audit, wiring status, self-healing status, ' +
        'list approvals, approve/reject an approval, list plugins, describe an organ, or create a goal.',
      status: 'not_understood',
    };
    await this.logUsage('unrecognized', text, ctx, result);
    return result;
  }

  private async logUsage(intentName: string, utterance: string, ctx: ChatContext, result: ChatResult): Promise<void> {
    try {
      await this.runtime.store.appendUsageEvent({
        id: randomUUID(),
        tenantId: ctx.tenantId,
        kind: 'chat',
        name: intentName,
        actorId: ctx.requestedBy,
        dataRefs: result.organId ? [result.organId] : [],
        metadata: { utteranceLength: utterance.length, status: result.status },
        createdAt: new Date().toISOString(),
      });
    } catch {
      // Logging must never break the chat response the user is waiting on.
    }
  }

  private async organStatus(organId: string, ctx: ChatContext) {
    return this.organs.invoke({ organId, operation: 'status', tenantId: ctx.tenantId, requestedBy: ctx.requestedBy });
  }

  private buildIntents(): Intent[] {
    return [
      {
        name: 'usage-report',
        patterns: [/usage report/i, /data usage/i, /how much.*used/i, /telemetry summary/i],
        describe: 'Usage summary: in-memory telemetry window plus durable, cross-restart history.',
        handle: async (_u, ctx) => {
          const governance = await this.organStatus('runtime-auditor', ctx);
          const events = this.runtime.telemetry.recent(500);
          const durable = await this.runtime.store.listUsageEvents(ctx.tenantId, 500);
          const byKind: Record<string, number> = {};
          for (const event of durable) byKind[event.kind] = (byKind[event.kind] || 0) + 1;
          return {
            reply: `In-memory window: ${events.length} events since last restart. Durable history: ${durable.length} events for this tenant across ${Object.keys(byKind).length} kinds.`,
            organId: 'runtime-auditor',
            route: '/api/autonomy/usage-report',
            data: { inMemoryEventCount: events.length, durableEventCount: durable.length, durableByKind: byKind },
            governance,
            status: 'ok',
          };
        },
      },
      {
        name: 'help',
        patterns: [/^help$/i, /what can you do/i, /capabilities/i, /list.*commands/i],
        describe: 'List what the chat surface can do.',
        handle: async () => ({
          reply:
            'I can report on: system status, organs, agents, compute, infrastructure, safe mode, audit, ' +
            'governance lock, wiring, self-healing, web-use posture, plugins, approvals, run status, and a usage report. ' +
            'I can also submit a new goal and approve/reject a pending approval.',
          status: 'ok',
        }),
      },
      {
        name: 'system-status',
        patterns: [/system status/i, /how are you/i, /introspect/i, /overall status/i],
        describe: 'Full system introspection.',
        handle: async (_u, ctx) => {
          const governance = await this.organStatus('runtime-auditor', ctx);
          const data = await this.runtime.introspect();
          return { reply: this.summarize('System introspection', data), organId: 'runtime-auditor', route: '/api/autonomy/introspection', data, governance, status: 'ok' };
        },
      },
      {
        name: 'list-organs',
        patterns: [/list organs/i, /what organs/i, /show organs/i],
        describe: 'List every registered organ.',
        handle: async () => {
          const organs = listOrgans();
          return {
            reply: `There are ${organs.length} registered organs across ${organSummary().families} families. Ask "describe <organ id>" for one specifically.`,
            data: { summary: organSummary(), organs },
            status: 'ok',
          };
        },
      },
      {
        name: 'describe-organ',
        patterns: [/describe organ (.+)/i, /what does (.+) organ do/i, /tell me about (.+) organ/i],
        describe: 'Describe a specific organ by id.',
        handle: async (utterance) => {
          const match = utterance.match(/describe organ (.+)/i) || utterance.match(/what does (.+) organ do/i) || utterance.match(/tell me about (.+) organ/i);
          const candidate = (match?.[1] || '').trim().toLowerCase().replace(/\s+/g, '-');
          const organ = getOrgan(candidate) || listOrgans().find((o) => o.name.toLowerCase().includes(candidate));
          if (!organ) return { reply: `I couldn't find an organ matching "${candidate}".`, status: 'not_understood' };
          return { reply: `${organ.name} (family ${organ.familyNumber}, ${organ.mode}): ${organ.guidedPath}`, data: organ, status: 'ok' };
        },
      },
      {
        name: 'agents',
        patterns: [/agent posture/i, /list agents/i, /show agents/i],
        describe: 'Agent registry and posture.',
        handle: async (_u, ctx) => {
          const governance = await this.organStatus('agent-registry', ctx);
          const agents = await this.runtime.listAgents(ctx.tenantId);
          return { reply: `There are ${agents.length} agents registered for tenant "${ctx.tenantId}".`, organId: 'agent-registry', route: '/api/autonomy/agents', data: agents, governance, status: 'ok' };
        },
      },
      {
        name: 'compute',
        patterns: [/compute status/i, /compute posture/i, /gpu status/i, /cpu status/i],
        describe: 'Compute posture.',
        handle: async (_u, ctx) => {
          const governance = await this.organStatus('device-capability-organ', ctx);
          const data = await this.runtime.computeAssessment(ctx.tenantId);
          return { reply: this.summarize('Compute posture', data), organId: 'device-capability-organ', route: '/api/autonomy/compute/posture', data, governance, status: 'ok' };
        },
      },
      {
        name: 'infrastructure',
        patterns: [/infrastructure status/i, /infra status/i],
        describe: 'Infrastructure posture.',
        handle: async (_u, ctx) => {
          const governance = await this.organStatus('device-capability-organ', ctx);
          const data = await this.runtime.infrastructurePosture(ctx.tenantId);
          return { reply: this.summarize('Infrastructure posture', data), organId: 'device-capability-organ', route: '/api/autonomy/infrastructure', data, governance, status: 'ok' };
        },
      },
      {
        name: 'safe-mode-status',
        patterns: [/safe mode status/i, /is safe mode/i],
        describe: 'Safe mode status.',
        handle: async (_u, ctx) => {
          const governance = await this.organStatus('safe-mode-control-organ', ctx);
          const data = await this.runtime.store.listLevel6Records('safe_mode', ctx.tenantId);
          return { reply: this.summarize('Safe mode', data), organId: 'safe-mode-control-organ', route: '/api/autonomy/safe-mode', data, governance, status: 'ok' };
        },
      },
      {
        name: 'safe-mode-set',
        patterns: [/(enable|turn on) safe mode/i, /(disable|turn off) safe mode/i],
        describe: 'Enable or disable safe mode (governed, may require approval).',
        handle: async (utterance, ctx) => {
          const enabled = /enable|turn on/i.test(utterance);
          const governance = await this.organs.invoke({ organId: 'safe-mode-control-organ', operation: 'prepare', tenantId: ctx.tenantId, payload: { enabled }, requestedBy: ctx.requestedBy });
          if (governance.outcome !== 'allowed') {
            return { reply: `That requires approval before it takes effect (safe mode ${enabled ? 'on' : 'off'}).`, organId: 'safe-mode-control-organ', governance, status: 'awaiting_approval' };
          }
          const result = await this.runtime.setSafeMode(enabled, ctx.requestedBy, 'Requested via chat.');
          return { reply: `Safe mode is now ${enabled ? 'ON' : 'OFF'}.`, organId: 'safe-mode-control-organ', data: result, governance, status: 'ok' };
        },
      },
      {
        name: 'audit',
        patterns: [/full audit/i, /audit report/i, /run an audit/i],
        describe: 'Full system audit.',
        handle: async (_u, ctx) => {
          const governance = await this.organStatus('runtime-auditor', ctx);
          const data = await this.runtime.fullSystemAudit(ctx.tenantId);
          return { reply: this.summarize('Audit', data), organId: 'runtime-auditor', route: '/api/autonomy/audit', data, governance, status: 'ok' };
        },
      },
      {
        name: 'governance-lock',
        patterns: [/governance lock/i, /paragon status/i],
        describe: 'Governance lock posture.',
        handle: async (_u, ctx) => {
          const governance = await this.organStatus('paragon-dissector', ctx);
          const data = await this.runtime.governanceLockPosture(ctx.tenantId);
          return { reply: this.summarize('Governance lock', data), organId: 'paragon-dissector', route: '/api/autonomy/governance-lock', data, governance, status: 'ok' };
        },
      },
      {
        name: 'wiring',
        patterns: [/wiring status/i, /is everything wired/i],
        describe: 'Master wiring status.',
        handle: async (_u, ctx) => {
          const governance = await this.organStatus('organ-wiring-layer', ctx);
          const data = await this.runtime.masterWiringPosture(ctx.tenantId);
          return { reply: this.summarize('Wiring', data), organId: 'organ-wiring-layer', route: '/api/autonomy/wiring', data, governance, status: 'ok' };
        },
      },
      {
        name: 'self-healing',
        patterns: [/self.healing status/i, /healing report/i],
        describe: 'Self-healing posture.',
        handle: async (_u, ctx) => {
          const governance = await this.organStatus('health-trigger-organ', ctx);
          const data = await this.runtime.selfHealingPosture(ctx.tenantId);
          return { reply: this.summarize('Self-healing', data), organId: 'health-trigger-organ', route: '/api/autonomy/self-healing', data, governance, status: 'ok' };
        },
      },
      {
        name: 'web-use',
        patterns: [/web.use posture/i, /browser automation status/i],
        describe: 'Web-use posture.',
        handle: async (_u, ctx) => {
          const governance = await this.organStatus('web-automation-organ', ctx);
          const data = await this.runtime.webUsePosture(ctx.tenantId);
          return { reply: this.summarize('Web-use posture', data), organId: 'web-automation-organ', route: '/api/autonomy/web/posture', data, governance, status: 'ok' };
        },
      },
      {
        name: 'plugins',
        patterns: [/list plugins/i, /show plugins/i, /what plugins/i, /list integrations/i],
        describe: 'List registered plugins.',
        handle: async () => ({ reply: 'Listing registered plugins.', route: '/api/autonomy/plugins', status: 'ok' }),
      },
      {
        name: 'approvals-list',
        patterns: [/pending approvals/i, /list approvals/i, /what needs approval/i],
        describe: 'List approvals.',
        handle: async (_u, ctx) => {
          const governance = await this.organStatus('tenant-registry', ctx);
          const approvals = await this.runtime.listApprovals(ctx.tenantId, 'pending');
          return { reply: `There are ${approvals.length} pending approvals.`, organId: 'tenant-registry', route: '/api/autonomy/approvals', data: approvals, governance, status: 'ok' };
        },
      },
      {
        name: 'approval-decide',
        patterns: [/(approve|reject) approval (\S+)/i],
        describe: 'Approve or reject a specific approval by id (governed).',
        handle: async (utterance, ctx) => {
          const match = utterance.match(/(approve|reject) approval (\S+)/i)!;
          const approved = match[1].toLowerCase() === 'approve';
          const approvalId = match[2];
          const governance = await this.organs.invoke({ organId: 'approval-control-organ', operation: 'prepare', tenantId: ctx.tenantId, payload: { approvalId, approved }, requestedBy: ctx.requestedBy });
          if (governance.outcome !== 'allowed') {
            return { reply: `That decision itself requires further approval before it applies.`, organId: 'approval-control-organ', governance, status: 'awaiting_approval' };
          }
          const approval = await this.runtime.decideApproval(approvalId, approved, 'Decided via chat.', ctx.requestedBy, ctx.tenantId);
          if (!approval) return { reply: `I couldn't find an approval with id "${approvalId}".`, status: 'not_understood' };
          return { reply: `Approval ${approvalId} was ${approved ? 'approved' : 'rejected'}.`, organId: 'approval-control-organ', data: approval, governance, status: 'ok' };
        },
      },
      {
        name: 'submit-goal',
        patterns: [/^(create a goal to|run|start a task to|new goal:?) (.+)/i],
        describe: 'Submit a new goal for the planner (still governed step by step).',
        handle: async (utterance, ctx) => {
          const match = utterance.match(/^(create a goal to|run|start a task to|new goal:?) (.+)/i)!;
          const goalText = match[2].trim();
          const run = await this.runtime.submitGoal({ goal: goalText, tenantId: ctx.tenantId, requestedBy: ctx.requestedBy, metadata: { source: 'chat' } });
          return { reply: `Goal submitted: "${goalText}". Run id is ${run.id}. Every step still goes through Paragon individually.`, route: '/api/autonomy/goals', data: run, status: 'ok' };
        },
      },
      {
        name: 'run-status',
        patterns: [/status of run (\S+)/i, /run (\S+) status/i],
        describe: 'Get the status of a specific run.',
        handle: async (utterance, ctx) => {
          const match = utterance.match(/status of run (\S+)/i) || utterance.match(/run (\S+) status/i);
          const runId = match?.[1];
          if (!runId) return { reply: 'Which run id?', status: 'not_understood' };
          const detail = await this.runtime.getRunWithSteps(runId);
          if (!detail || detail.run.tenantId !== ctx.tenantId) return { reply: `I couldn't find run "${runId}" in this tenant.`, status: 'not_understood' };
          return { reply: `Run ${runId} is ${detail.run.status}, on step ${detail.run.currentStep} of ${detail.run.plan.length}.`, data: detail, status: 'ok' };
        },
      },
    ];
  }

  private summarize(label: string, data: unknown): string {
    if (data && typeof data === 'object') {
      const keys = Object.keys(data as Record<string, unknown>).slice(0, 6);
      return `${label}: ${keys.join(', ')}${keys.length < Object.keys(data as Record<string, unknown>).length ? ', ...' : ''}. Full detail is in the response payload.`;
    }
    return `${label}: ${String(data)}`;
  }
}
