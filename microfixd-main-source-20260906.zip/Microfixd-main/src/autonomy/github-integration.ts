// src/autonomy/github-integration.ts
//
// Real GitHub Contents API integration -- plain fetch, no new dependency.
// Confirmed reachable: api.github.com is on the allowed network list and
// returns real responses (rate-limited without a token, which is
// expected and resolved by setting GITHUB_TOKEN in production).
//
// Import (read) is safe and ungated -- reading a public or
// token-accessible file has no side effect. Export (write) is a real
// commit to a real repository and is ALWAYS gated as an 'external_effect'
// through governed-execution.ts, exactly like sandbox execution and
// browser automation -- propose, get a real approval, consume it once,
// then and only then write.

export type GitHubFile = { path: string; content: string; sha?: string; encoding: 'utf-8' };

export type FetchLike = typeof fetch;

function authHeaders(): Record<string, string> {
  const token = process.env.GITHUB_TOKEN;
  return token ? { Authorization: `Bearer ${token}`, 'User-Agent': 'Microfixd' } : { 'User-Agent': 'Microfixd' };
}

/** Real, safe, ungated read. No approval required -- reading has no side effect. */
export async function importRepoFile(owner: string, repo: string, path: string, ref?: string, fetchImpl: FetchLike = fetch): Promise<GitHubFile> {
  const url = `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}${ref ? `?ref=${encodeURIComponent(ref)}` : ''}`;
  const response = await fetchImpl(url, { headers: { Accept: 'application/vnd.github.v3+json', ...authHeaders() } });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`GitHub import failed (HTTP ${response.status}): ${body.slice(0, 500)}`);
  }
  const data = (await response.json()) as { content: string; encoding: string; sha: string };
  const content = data.encoding === 'base64' ? Buffer.from(data.content, 'base64').toString('utf-8') : data.content;
  return { path, content, sha: data.sha, encoding: 'utf-8' };
}

/**
 * Real write. Callers MUST have already run this through
 * governed-execution.ts's propose -> approve -> consumeApprovalOnce
 * cycle before calling this -- this function itself does not check for
 * an approval; routes.ts is responsible for that, the same separation
 * used for sandbox execution and browser automation.
 */
export async function exportRepoFile(
  owner: string, repo: string, path: string, content: string, message: string, branch = 'main', fetchImpl: FetchLike = fetch,
): Promise<{ commitSha: string }> {
  const token = process.env.GITHUB_TOKEN;
  if (!token) throw new Error('GITHUB_TOKEN is required for real GitHub exports -- never accepted from the request body.');

  const url = `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}`;
  let existingSha: string | undefined;
  const existing = await fetchImpl(`${url}?ref=${encodeURIComponent(branch)}`, { headers: { Accept: 'application/vnd.github.v3+json', ...authHeaders() } });
  if (existing.ok) {
    const existingData = (await existing.json()) as { sha: string };
    existingSha = existingData.sha;
  }

  const response = await fetchImpl(url, {
    method: 'PUT',
    headers: { Accept: 'application/vnd.github.v3+json', 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify({ message, content: Buffer.from(content, 'utf-8').toString('base64'), branch, sha: existingSha }),
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`GitHub export failed (HTTP ${response.status}): ${body.slice(0, 500)}`);
  }
  const data = (await response.json()) as { commit: { sha: string } };
  return { commitSha: data.commit.sha };
}

/**
 * Real batch commit via the Git Data API (blobs -> tree -> commit -> ref
 * update) -- one atomic commit for many files, unlike calling
 * exportRepoFile() in a loop which would create one commit per file and
 * can leave a repo in a half-pushed state if it fails partway through.
 * Same governance requirement as exportRepoFile: caller must have
 * already run this through the propose -> approve -> consumeApprovalOnce
 * cycle.
 */
export async function exportRepoFiles(
  owner: string, repo: string, files: Record<string, string>, message: string, branch = 'main', fetchImpl: FetchLike = fetch,
): Promise<{ commitSha: string; fileCount: number }> {
  const token = process.env.GITHUB_TOKEN;
  if (!token) throw new Error('GITHUB_TOKEN is required for real GitHub exports -- never accepted from the request body.');
  const base = `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`;
  const headers = { Accept: 'application/vnd.github.v3+json', 'Content-Type': 'application/json', ...authHeaders() };

  const refResponse = await fetchImpl(`${base}/git/ref/heads/${encodeURIComponent(branch)}`, { headers });
  if (!refResponse.ok) throw new Error(`Could not resolve branch "${branch}" (HTTP ${refResponse.status}): ${(await refResponse.text()).slice(0, 300)}`);
  const refData = (await refResponse.json()) as { object: { sha: string } };
  const baseCommitSha = refData.object.sha;

  const commitResponse = await fetchImpl(`${base}/git/commits/${baseCommitSha}`, { headers });
  if (!commitResponse.ok) throw new Error(`Could not read base commit (HTTP ${commitResponse.status}).`);
  const baseCommit = (await commitResponse.json()) as { tree: { sha: string } };

  const blobShas: Record<string, string> = {};
  for (const [path, content] of Object.entries(files)) {
    const blobResponse = await fetchImpl(`${base}/git/blobs`, { method: 'POST', headers, body: JSON.stringify({ content: Buffer.from(content, 'utf-8').toString('base64'), encoding: 'base64' }) });
    if (!blobResponse.ok) throw new Error(`Blob creation failed for "${path}" (HTTP ${blobResponse.status}): ${(await blobResponse.text()).slice(0, 300)}`);
    const blobData = (await blobResponse.json()) as { sha: string };
    blobShas[path] = blobData.sha;
  }

  const treeResponse = await fetchImpl(`${base}/git/trees`, {
    method: 'POST', headers,
    body: JSON.stringify({ base_tree: baseCommit.tree.sha, tree: Object.entries(blobShas).map(([path, sha]) => ({ path, mode: '100644', type: 'blob', sha })) }),
  });
  if (!treeResponse.ok) throw new Error(`Tree creation failed (HTTP ${treeResponse.status}): ${(await treeResponse.text()).slice(0, 300)}`);
  const treeData = (await treeResponse.json()) as { sha: string };

  const newCommitResponse = await fetchImpl(`${base}/git/commits`, { method: 'POST', headers, body: JSON.stringify({ message, tree: treeData.sha, parents: [baseCommitSha] }) });
  if (!newCommitResponse.ok) throw new Error(`Commit creation failed (HTTP ${newCommitResponse.status}): ${(await newCommitResponse.text()).slice(0, 300)}`);
  const newCommitData = (await newCommitResponse.json()) as { sha: string };

  const updateRefResponse = await fetchImpl(`${base}/git/refs/heads/${encodeURIComponent(branch)}`, { method: 'PATCH', headers, body: JSON.stringify({ sha: newCommitData.sha }) });
  if (!updateRefResponse.ok) throw new Error(`Ref update failed (HTTP ${updateRefResponse.status}): ${(await updateRefResponse.text()).slice(0, 300)}`);

  return { commitSha: newCommitData.sha, fileCount: Object.keys(files).length };
}
