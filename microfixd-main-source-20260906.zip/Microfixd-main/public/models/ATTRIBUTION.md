# facecap.glb

Source: https://github.com/mrdoob/three.js/blob/dev/examples/models/gltf/facecap.glb
License: MIT (three.js authors, 2010-2026) -- same license as the three.js library itself.
Used as-is for the OS shell's presence-model head geometry (real facial topology from
three.js's ARKit blendshape demo asset), rendered with a custom holographic material
built for this project (see src/os/shell/use-wireframe-head.ts).
